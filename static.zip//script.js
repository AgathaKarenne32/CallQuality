// Data
const requirementsData = [
    {
        id: 'RF001',
        name: 'Autenticação de Usuário',
        description: 'O sistema deve permitir que usuários façam login usando email e senha, com autenticação via JWT.',
        actor: 'Atendente/Supervisor',
        priority: 'Alta'
    },
    {
        id: 'RF002',
        name: 'Upload de Áudio',
        description: 'O sistema deve permitir o upload de arquivos de áudio no formato MP3 ou WAV para análise.',
        actor: 'Atendente',
        priority: 'Alta'
    },
    {
        id: 'RF003',
        name: 'Análise Automatizada',
        description: 'O sistema deve processar o áudio e gerar uma avaliação baseada em critérios de qualidade (clareza, cortesia, resolução).',
        actor: 'Sistema',
        priority: 'Alta'
    },
    {
        id: 'RF004',
        name: 'Visualização de Resultados',
        description: 'O atendente deve poder visualizar a pontuação e o feedback detalhado da sua ligação.',
        actor: 'Atendente',
        priority: 'Alta'
    },
    {
        id: 'RF005',
        name: 'Dashboard Gerencial',
        description: 'Supervisores devem ter acesso a um painel com métricas agregadas (média de pontuações, número de ligações analisadas).',
        actor: 'Supervisor',
        priority: 'Alta'
    },
    {
        id: 'RF006',
        name: 'Filtragem de Ligações',
        description: 'O supervisor deve poder filtrar ligações por período, atendente ou pontuação.',
        actor: 'Supervisor',
        priority: 'Média'
    },
    {
        id: 'RF007',
        name: 'Exportação de Relatórios',
        description: 'O sistema deve permitir a exportação de relatórios em formato PDF ou Excel.',
        actor: 'Supervisor',
        priority: 'Média'
    },
    {
        id: 'RF008',
        name: 'Gestão de Usuários',
        description: 'Administradores devem poder criar, editar e desativar usuários no sistema.',
        actor: 'Administrador',
        priority: 'Alta'
    }
];

const nfrData = [
    {
        id: 'RNF001',
        name: 'Performance',
        description: 'A análise de uma ligação de até 10 minutos deve ser concluída em no máximo 30 segundos.',
        category: 'Desempenho',
        color: 'success',
        metrics: 'Tempo de resposta < 30s'
    },
    {
        id: 'RNF002',
        name: 'Segurança de Dados',
        description: 'Todas as senhas devem ser armazenadas com hash BCrypt. Comunicação via HTTPS obrigatória.',
        category: 'Segurança',
        color: 'danger',
        metrics: 'BCrypt + HTTPS'
    },
    {
        id: 'RNF003',
        name: 'Escalabilidade',
        description: 'O sistema deve suportar até 10.000 usuários simultâneos sem degradação de performance.',
        category: 'Escalabilidade',
        color: 'primary',
        metrics: '10k usuários simultâneos'
    },
    {
        id: 'RNF004',
        name: 'Disponibilidade',
        description: 'O sistema deve ter 99.5% de disponibilidade mensal (downtime máximo de 3.6 horas/mês).',
        category: 'Confiabilidade',
        color: 'warning',
        metrics: '99.5% uptime'
    },
    {
        id: 'RNF005',
        name: 'Compatibilidade',
        description: 'A aplicação web deve funcionar nos navegadores Chrome, Firefox, Safari e Edge (últimas 2 versões).',
        category: 'Compatibilidade',
        color: 'info',
        metrics: 'Cross-browser'
    },
    {
        id: 'RNF006',
        name: 'Auditoria',
        description: 'Todas as ações críticas (login, upload, exclusão) devem ser registradas em logs.',
        category: 'Auditoria',
        color: 'purple',
        metrics: 'Logs completos'
    },
    {
        id: 'RNF007',
        name: 'Conformidade LGPD',
        description: 'O sistema deve estar em conformidade com a Lei Geral de Proteção de Dados (LGPD).',
        category: 'Conformidade',
        color: 'pink',
        metrics: 'LGPD compliant'
    }
];

const rulesData = [
    {
        id: 'RN001',
        name: 'Critérios de Avaliação',
        description: 'A pontuação final de uma ligação é calculada pela média ponderada de 5 critérios: Clareza (peso 20%), Cortesia (20%), Objetividade (20%), Resolução do Problema (30%), Tempo de Atendimento (10%).',
        type: 'Cálculo',
        color: 'primary',
        impact: 'Crítico',
        example: 'Pontuação = (Clareza×0.2) + (Cortesia×0.2) + (Objetividade×0.2) + (Resolução×0.3) + (Tempo×0.1)'
    },
    {
        id: 'RN002',
        name: 'Tamanho Máximo de Arquivo',
        description: 'Arquivos de áudio não podem exceder 50MB. Ligações com mais de 30 minutos devem ser fragmentadas.',
        type: 'Validação',
        color: 'danger',
        impact: 'Alto',
        example: 'Limite: 50MB ou 30 minutos de áudio'
    },
    {
        id: 'RN003',
        name: 'Nível de Acesso',
        description: 'Apenas supervisores podem visualizar dados de todos os atendentes. Atendentes só podem acessar suas próprias avaliações.',
        type: 'Autorização',
        color: 'warning',
        impact: 'Crítico',
        example: 'Atendente: ver apenas próprios dados | Supervisor: ver todos'
    },
    {
        id: 'RN004',
        name: 'Threshold de Alerta',
        description: 'Se a pontuação de uma ligação for inferior a 60%, o sistema deve gerar um alerta automático para o supervisor.',
        type: 'Processamento',
        color: 'success',
        impact: 'Alto',
        example: 'Score < 60% → Alerta automático'
    },
    {
        id: 'RN005',
        name: 'Retenção de Dados',
        description: 'Ligações e avaliações devem ser mantidas no sistema por no mínimo 12 meses para fins de auditoria.',
        type: 'Processamento',
        color: 'success',
        impact: 'Médio',
        example: 'Período mínimo: 12 meses'
    },
    {
        id: 'RN006',
        name: 'Tentativas de Login',
        description: 'Após 5 tentativas incorretas de login, a conta do usuário deve ser bloqueada temporariamente por 15 minutos.',
        type: 'Validação',
        color: 'danger',
        impact: 'Alto',
        example: '5 falhas → Bloqueio de 15 minutos'
    },
    {
        id: 'RN007',
        name: 'Formato de Pontuação',
        description: 'Todas as pontuações devem ser exibidas em escala de 0 a 100, com duas casas decimais.',
        type: 'Cálculo',
        color: 'primary',
        impact: 'Médio',
        example: 'Formato: 85.75 (0-100)'
    },
    {
        id: 'RN008',
        name: 'Idioma de Análise',
        description: 'O sistema deve suportar análise de ligações em português brasileiro. Ligações em outros idiomas devem ser rejeitadas.',
        type: 'Validação',
        color: 'danger',
        impact: 'Crítico',
        example: 'Idioma suportado: PT-BR'
    }
];

const tablesData = [
    {
        name: 'tb_usuario',
        displayName: 'Usuário',
        color: 'primary',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'nome', type: 'VARCHAR(100)', constraint: 'NOT NULL' },
            { name: 'email', type: 'VARCHAR(100)', constraint: 'UNIQUE' },
            { name: 'senha', type: 'VARCHAR(255)', constraint: 'NOT NULL' },
            { name: 'tipo_usuario', type: 'ENUM', constraint: 'NOT NULL' },
            { name: 'ativo', type: 'BOOLEAN', constraint: 'DEFAULT TRUE' }
        ]
    },
    {
        name: 'tb_ligacao',
        displayName: 'Ligação',
        color: 'success',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'usuario_id', type: 'BIGINT', constraint: 'FK' },
            { name: 'arquivo_audio', type: 'VARCHAR(255)', constraint: 'NOT NULL' },
            { name: 'duracao', type: 'INT', constraint: '' },
            { name: 'data_upload', type: 'TIMESTAMP', constraint: 'DEFAULT NOW()' },
            { name: 'status', type: 'ENUM', constraint: 'NOT NULL' }
        ]
    },
    {
        name: 'tb_avaliacao',
        displayName: 'Avaliação',
        color: 'warning',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'ligacao_id', type: 'BIGINT', constraint: 'FK' },
            { name: 'pontuacao_final', type: 'DECIMAL(5,2)', constraint: 'NOT NULL' },
            { name: 'clareza', type: 'DECIMAL(5,2)', constraint: '' },
            { name: 'cortesia', type: 'DECIMAL(5,2)', constraint: '' },
            { name: 'objetividade', type: 'DECIMAL(5,2)', constraint: '' },
            { name: 'data_avaliacao', type: 'TIMESTAMP', constraint: 'DEFAULT NOW()' }
        ]
    },
    {
        name: 'tb_criterio',
        displayName: 'Critério',
        color: 'purple',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'nome', type: 'VARCHAR(50)', constraint: 'UNIQUE' },
            { name: 'descricao', type: 'TEXT', constraint: '' },
            { name: 'peso', type: 'DECIMAL(3,2)', constraint: 'NOT NULL' },
            { name: 'ativo', type: 'BOOLEAN', constraint: 'DEFAULT TRUE' }
        ]
    },
    {
        name: 'tb_relatorio',
        displayName: 'Relatório',
        color: 'pink',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'usuario_id', type: 'BIGINT', constraint: 'FK' },
            { name: 'tipo_relatorio', type: 'ENUM', constraint: 'NOT NULL' },
            { name: 'periodo_inicio', type: 'DATE', constraint: '' },
            { name: 'periodo_fim', type: 'DATE', constraint: '' },
            { name: 'data_geracao', type: 'TIMESTAMP', constraint: 'DEFAULT NOW()' }
        ]
    },
    {
        name: 'tb_log_auditoria',
        displayName: 'Log de Auditoria',
        color: 'info',
        fields: [
            { name: 'id', type: 'BIGINT', constraint: 'PK' },
            { name: 'usuario_id', type: 'BIGINT', constraint: 'FK' },
            { name: 'acao', type: 'VARCHAR(100)', constraint: 'NOT NULL' },
            { name: 'tabela_afetada', type: 'VARCHAR(50)', constraint: '' },
            { name: 'registro_id', type: 'BIGINT', constraint: '' },
            { name: 'timestamp', type: 'TIMESTAMP', constraint: 'DEFAULT NOW()' }
        ]
    }
];

// Navigation
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const sectionId = item.getAttribute('data-section');
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            // Update active section
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(sectionId).classList.add('active');
        });
    });
}

// Render Requirements Table
function renderRequirements(filter = 'Todos') {
    const container = document.getElementById('requirementsTable');
    const filtered = filter === 'Todos' 
        ? requirementsData 
        : requirementsData.filter(req => req.actor.includes(filter));
    
    container.innerHTML = filtered.map(req => `
        <div class="table-row">
            <div class="id">${req.id}</div>
            <div class="name">${req.name}</div>
            <div class="description">${req.description}</div>
            <div>
                <span class="badge badge-${req.actor.toLowerCase().replace('/', '-')}">${req.actor}</span>
            </div>
            <div class="${req.priority === 'Alta' ? 'priority-high' : 'priority-medium'}">${req.priority}</div>
        </div>
    `).join('');
}

// Render NFRs
function renderNFRs() {
    const container = document.getElementById('nfrContainer');
    
    container.innerHTML = nfrData.map(nfr => `
        <div class="nfr-card">
            <div class="nfr-header">
                <div class="nfr-icon bg-${nfr.color}">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                    </svg>
                </div>
                <div class="nfr-content">
                    <div class="nfr-title">
                        <span class="nfr-id">${nfr.id}</span>
                        <span class="nfr-name">${nfr.name}</span>
                        <span class="badge badge-${nfr.category.toLowerCase()}" style="margin-left: auto;">${nfr.category}</span>
                    </div>
                    <p class="nfr-description">${nfr.description}</p>
                    <span class="nfr-metric">📊 Métrica: ${nfr.metrics}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Render Business Rules
function renderRules() {
    const container = document.getElementById('rulesContainer');
    
    // Count by type
    const typeCounts = {};
    rulesData.forEach(rule => {
        typeCounts[rule.type] = (typeCounts[rule.type] || 0) + 1;
    });
    
    const typeCards = Object.entries(typeCounts).map(([type, count]) => {
        const rule = rulesData.find(r => r.type === type);
        return `
            <div class="stat-card">
                <div class="stat-icon bg-${rule.color}">
                    <span style="color: white; font-size: 24px; font-weight: bold;">${count}</span>
                </div>
                <div class="stat-value">${type}</div>
                <div class="stat-detail">${count} regras</div>
            </div>
        `;
    }).join('');
    
    const ruleCards = rulesData.map(rule => `
        <div class="rule-card">
            <div class="rule-header">
                <div class="rule-title">
                    <span class="nfr-id">${rule.id}</span>
                    <h3>${rule.name}</h3>
                </div>
                <div class="rule-impact">
                    <span style="color: var(--${rule.impact === 'Crítico' ? 'danger' : rule.impact === 'Alto' ? 'warning' : 'success'});">${rule.impact}</span>
                </div>
            </div>
            <p class="rule-description">${rule.description}</p>
            <div class="rule-footer">
                <span class="badge badge-${rule.type.toLowerCase()}">${rule.type}</span>
                ${rule.example ? `<span class="rule-example">${rule.example}</span>` : ''}
            </div>
        </div>
    `).join('');
    
    container.innerHTML = `
        <div class="grid-4 mb-24">${typeCards}</div>
        ${ruleCards}
    `;
}

// Render Database
function renderDatabase() {
    const container = document.getElementById('databaseContainer');
    
    const tableCards = tablesData.map(table => `
        <div class="db-table">
            <div class="db-table-header bg-${table.color}">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
                    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
                </svg>
                <div>
                    <div class="db-table-name">${table.name}</div>
                    <div class="db-table-display">${table.displayName}</div>
                </div>
            </div>
            <div class="db-table-body">
                ${table.fields.map(field => `
                    <div class="db-field">
                        ${field.constraint === 'PK' ? '<svg viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>' : ''}
                        ${field.constraint === 'FK' ? '<svg viewBox="0 0 24 24" fill="none" stroke="#4F46E5" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>' : ''}
                        <span class="field-name">${field.name}</span>
                        <span class="field-type">${field.type}</span>
                        ${field.constraint ? `<span class="field-constraint">${field.constraint}</span>` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
    
    container.innerHTML = `
        <div class="content-card mb-24">
            <h2>Diagrama Entidade-Relacionamento</h2>
            <div class="grid-3">
                ${tableCards}
            </div>
        </div>
    `;
}

// Initialize Filter
function initFilter() {
    const filter = document.getElementById('actorFilter');
    filter.addEventListener('change', (e) => {
        renderRequirements(e.target.value);
    });
}

// Initialize everything
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    renderRequirements();
    renderNFRs();
    renderRules();
    renderDatabase();
    initFilter();
});
